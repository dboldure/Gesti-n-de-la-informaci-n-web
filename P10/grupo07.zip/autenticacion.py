# -*- coding: utf-8 -*-

# =============================================================================
# ## Asignatura: Gestión de la información en la Web
# ## Practica Autenticaci ́on & TOTP
# ## Grupo: 7
# ## Autores: MIGUEL ÁNGEL ARROYO CLEMENTE, DANIELA-NICOLETA BOLDUREANU, DAVID PRATS ULLOA, IVÁN RUIZ QUINTANA
# ## MIGUEL ÁNGEL ARROYO CLEMENTE, DANIELA-NICOLETA BOLDUREANU, DAVID PRATS ULLOA, IVÁN RUIZ QUINTANA declaramos 
# ## que esta solución es fruto exclusivamente de nuestro trabajo personal. 
# ## No hemos sido ayudados por ninguna otra persona ni hemos obtenido la solución de fuentes externas, 
# ## y tampoco hemos compartido nuestra solución con nadie. 
# ## Declaramos además que no hemos realizado de manera deshonesta ninguna otra 
# ## actividad que pueda mejorar nuestros resultados ni perjudicar los resultados de los demás. 
# =============================================================================

from bottle import *
import pymongo
import hashlib
import os
import base64
import onetimepass as otp
# Resto de importaciones


##############
# APARTADO 1 #
##############

# =============================================================================
# En primer lugar especificar que el metodo elegido es encrptacion + sal + reletizado
# el uso de relentizado no detiene los ataques de fuerza bruta, diccionarios de hashes o 
# el uso de tablas, simplemente hace que estos métodos sean más difíciles computacionalmente.
# 
# En primer lugar se crea la sal, generando un numero aleatorio de 60 digitos, 
# ademas esa sal se encripta con el metodo sha 256, con la sal conseguimos que al concatenar 
# con la contraseña no se puedan utilizar tablas ni diccionarios,
# ya que la contraseña no será unicamente la contraseña, sino que será la contraseña cifrada junto a la sal.
# 
# En segundo lugar se debe cifrar la contraseña, y para cifrarla utilizaremos el metodo sha 512, 
# ademas de utilizar el relentizado, por tanto se utiliza la función:
#     
#     hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), salt, 65536)
#     
# Esta funcion utiliza el relentizado pbkdf2, ademas le indicamos que metodo de cifrado haremos que será
# el mencionado antes sha 512, que es lo suficientemente seguro, ademas la propia función introduce la sal
# en el cifrado, para ello tambien la incluimos, y por ultimo se indica las iteraciones de relentizado,
# en nustro caso 65536.
# 
# Por tanto, como resultado, obtenemos la clave cifrada, relentizada y concatenada a la sal
# esto lo guardamos en la base de datos, ademas tambien guardamos la sal, no tiene por que ser privada.
# 
# Para el registro se hace lo explicado con anterioridad, para el login lo que se hace es en primer lugar obtener 
# la contraseña introducida por el usuario, y la sal de la base de datos para ese usuario concreto,
# se hace el procedimiento anterior pero con la contraseña introducida, esto da como resultado una cadena hash
# esta cadena se compara con el hash del usuario que está en la base de datos y asi solo si la contraseña es igual, 
# la funcion de hash y relentizado habra producido la misma cadena hash que esta en la base de datos y por tanto es correcta.
# 
# En el caso del cambio de contraseña se hace una mezcla de lo anterior, en primer lugar se comprueba la contraseña
# antigua introducida por el usuario con la contraseña que aparece en la bd como si fuese a hacer login, pero si es correcta,
# se hace lo mismo que en el registro, se genera una nueva sal y con ella se ecripta 
# la contraseña nueva introducida por el usuario mediante el metodo de relentizado y se almacena de nuevo en la base de datos.
# =============================================================================

#Esquema del usuario en la base de datos:

	#"_id" : ObjectId("584ebd92323e95478e6272f4"),
    #"name" : "Miguel",
    #"country" : "España",
    #"email" : "miguel@pepe.com",
	#"credentials" : {
	#		"nickname" : "miguel@pepe.com",
	#		"password" : "--------",
    #       "salt" : "--------"
	#	}

@post('/signup')
def signup():
    #obtenemos los parametros del formulario
    nickname = request.forms.get('nickname')
    name = request.forms.get('name')
    country = request.forms.get('country')
    email = request.forms.get('email')
    password = request.forms.get('password')
    password2 = request.forms.get('password2')
    
    #Verificación de datos introducidos (no debe haber nngun campo vacío)
    if nickname != "" and name != "" and country != "" and email != "" and password != "" and password2 != "":
        #Verificación de contraseña, las contraseñas deben ser iguales
        if password == password2:
            #Conexión con el cliente
            client = pymongo.MongoClient()
            #base de datos
            db = client.giw
            #obtencion de la colección
            colUser = db.users
            #Verificación de alias (no debe existir ningun usuario con el alias introducido)
            user = list(colUser.find({'credentials.nickname': nickname}))
            if len(user)==0:
                #Si todo es correcto se genera la sal y
                salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
                #se encripta con relentizado pbkdf2 y funcion hash sha512
                key = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), salt, 65536)
                
                #Creación del documento a insertar
                user = {"name" : name, 
                        "country" : country, 
                        "email" : email,
                        "credentials" : {
                                "nickname" : nickname,
                                "password" : key,
                                "salt" : salt
                        }}
                
                #se inserta el usuario
                insertUser = colUser.insert_one(user)
                #se optiene el usuario insertado
                newUser = colUser.find_one({"_id": insertUser.inserted_id})
                
                #Template de bienvenida
                bienvenida = "Bienvenido usuario " + newUser["name"]
                return template("Result.tpl", tabTitle = "Bienvenido", title = "Bienvenido", content = bienvenida, qr = "")
            else:
                return template("Result.tpl", tabTitle = "Error", title = "Error en alias", content = "El alias de usuario ya existe", qr = "")
        else:
            return template("Result.tpl", tabTitle = "Error", title = "Error en contraseña", content = "Las contraseñas no coinciden", qr = "")
    else:
        return template("Result.tpl", tabTitle = "Error", title = "Error en campos", content = "Existen algunos campo requeridos incompletos", qr = "")

           
    

@post('/change_password')
def change_password():
    #obtenemos los parametros del formulario
    nickname = request.forms.get('nickname')
    old_password = request.forms.get('old_password')
    new_password = request.forms.get('new_password')
    
    #Verificación de datos introducidos (no debe haber nngun campo vacío)
    if nickname != "" and old_password != "" and new_password != "":
        #Verificación de alias
        #Conexión con el cliente
        client = pymongo.MongoClient()
        #base de datos
        db = client.giw
        #obtencion de la colección
        colUser = db.users
        
        #Verificación de alias (debe existir el usuario con el alias especificado)
        user = colUser.find_one({'credentials.nickname': nickname})
        if user != None:
            ##verificacion
            #Sal guardada para ese usuario
            salt = user["credentials"]["salt"]
            #contraseña del usuario en la bd
            stored_password = user["credentials"]["password"]
            #Encriptación de la contraseña vieja introducida por el usuario
            pwdhash = hashlib.pbkdf2_hmac('sha512', 
                                          old_password.encode('utf-8'), 
                                          salt, 
                                          65536)
            #si el resultado de encriptacion coincide con el resultad de encriptacion almacenado en la bd, osea su contradeña real, es que es correcta
            if pwdhash == stored_password:
                #Si todo es correcto se genera la sal y
                salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
                #se encripta con relentizado pbkdf2 y funcion hash sha512
                key = hashlib.pbkdf2_hmac('sha512', new_password.encode('utf-8'), salt, 65536)
                
                #query para seleccionar el usuario a modificar
                findQuery = { "_id": user["_id"]}
                #query con nuevos valores
                values = { "$set": { "credentials.salt": salt, "credentials.password": key}}

                #ejecucion de la consulta de actualización con la nueva clave y sal generados
                updateUser = colUser.update(findQuery, values)
                #si se ha modificado correctamente se notifica con un template
                if updateUser['nModified'] == 1:
                    bienvenida = "La contraseña del usuario "+ user["credentials"]["nickname"] +" ha sido modificada."
                    return template("Result.tpl", tabTitle = "Update", title = "Update", content = bienvenida, qr = "")
                else:
                    return template("Result.tpl", tabTitle = "Error", title = "Error al actualizar", content = "No se ha podido actualizar el usuario, intentelo de nuevo", qr = "")
            else:
                return template("Result.tpl", tabTitle = "Error", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
        else:
            return template("Result.tpl", tabTitle = "Error", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
    else:
        return template("Result.tpl", tabTitle = "Error", title = "Error en campos", content = "Existen algunos campo requeridos incompletos", qr = "")

            

@post('/login')
def login():
    #obtenemos los parametros del formulario
    nickname = request.forms.get('nickname')
    password = request.forms.get('password')
    
    #Verificación de datos introducidos (no debe haber nngun campo vacío)
    if nickname != "" and password != "":
        #Conexión con el cliente
        client = pymongo.MongoClient()
        #base de datos
        db = client.giw
        #obtencion de la colección
        colUser = db.users
        #Verificación de alias (debe existir el usuario con el alias especificado)
        user = colUser.find_one({'credentials.nickname': nickname})
        if user != None:
            #obtencion de la Sal guardada para ese usuario
            salt = user["credentials"]["salt"]
            #contraseña del usuario en la bd
            stored_password = user["credentials"]["password"]
            #Encriptación de la contraseña introducida por el usuario
            pwdhash = hashlib.pbkdf2_hmac('sha512', 
                                          password.encode('utf-8'), 
                                          salt, 
                                          65536)
            #si el resultado de encriptacion coincide con el resultado de encriptacion almacenado en la bd, 
            #osea su contradeña real, entonces es que la contraseña introducida es correcta
            if pwdhash == stored_password:
                bienvenida = "Bienvenido " + user["name"]
                return template("Result.tpl", tabTitle = "Login", title = "Login", content = bienvenida, qr = "")
            else:
                return template("Result.tpl", tabTitle = "Error", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
        else:
            return template("Result.tpl", tabTitle = "Error", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
    else:
        return template("Result.tpl", tabTitle = "Error", title = "Error en campos", content = "Existen algunos campo requeridos incompletos", qr = "")



##############
# APARTADO 2 #
##############
        
# =============================================================================
# Este metodo es igual que el anterior con la excepción de que se crea una semilla aleatoria
# en base 32 mediante la libreria base64, lo que hacemos es generar un numero aleatorio de 60 digitos, 
# y despues lo codificamos en base 32 y lo guardamos en la base de datos,
# para que el usuario pueda pueda crear su cuenta el google authencicator se le da la semilla y el nombre pero para
# que sea mas facil se le proporciona un codigo qr generado gracias a la api de QR Code Generator, 
# ara ello directamente se le hace una peticion de tipo GET a la siguiente direccion: 
#     http(s)://api.qrserver.com/v1/create-qr-code/?data=[URL-encoded-text]&size=[pixels]x[pixels]
# esto se hace directamente desde el contenido html ya que no cambia, pero lo que si cambia es un dto que se envia al template 
# que es [URL-encoded-text] de la url anterior, esa será la url de google authenticator,
# esta url se construye de una manera especifica en el codigo, proporcionada por la documentación de google, se construye de la sigueinte manera:
#     otpauth://TYPE/LABEL?PARAMETERS
# TYPE en nuestro caso es totp ya que es basada en tiempo, LABEL es lo que queremos mostrarle al usuario, y los parametros son varios,
# secret=<SEMILLA DEL USUARIO>&issuer=<PROVEEDOR>&algorithm=<ALGORITMO DE CIFRADO QUE QUEREMOS UTILIZAR>&digits=<DIGITOS QUE QUEREMOS QUE TENGA EL CODIGO TOTP>&period=<PERIODO DE VALIDED DE UN CODIGO>
# 
# Con estos datos tenemos la url para google, que se introduce dentro de la petición GET del codigo QR y asi podemos generar un cogigo QR que el 
# usuario escanea con alguna app de generación de codigos totp y automaticamente lee la url contenida y genera un codigo totp para esa semilla.
# 
# En el caso del login se realiza igual que en los anteriores, con el añadido de un segundo paso, que normalmente se hace en otra pantalla
# pero por simplicidad lo hacemos todo al mismo tiempo, para ello utilizamos la libreria onetimepass, que contiene un metodo que verifica si un codigo 
# totp es acorde con un secreto en un momento dado, por lo que el usuario despues de introducir todos los datos, introduce el codigo totp dado por la 
# aplicación y una vez la app web ha verificado el usuario y contraseña, obtiene la semilla del usuario de la bd y aplica l verificacion del totp
# introducido con:
#     valid_totp(token=<TOTP>, secret=<SEMILLA>)
# si es valido entonces es que la verificación en 2 pasos ha funcionado, esto es mas seguro ya que aunque roben las claves o la bd se vea afectada y hackeada
# y los datos se vean expuestos, necesitará el codigo del dispositivo del usuariopara poder entrar.
# =============================================================================

@post('/signup_totp')
def signup_totp():
    #obtenemos los parametros del formulario
    nickname = request.forms.get('nickname')
    name = request.forms.get('name')
    country = request.forms.get('country')
    email = request.forms.get('email')
    password = request.forms.get('password')
    password2 = request.forms.get('password2')
    
    #Verificación de datos introducidos
    if nickname != "" and name != "" and country != "" and email != "" and password != "" and password2 != "":
        #Verificación de contraseña
        if password == password2:
            #Verificación de alias
            #Conexión con el cliente
            client = pymongo.MongoClient()
            #base de datos
            db = client.giw
            #obtencion de la colección
            colUser = db.users
            #no puede existir ningun usuario con el mismo alias
            user = list(colUser.find({'credentials.nickname': nickname}))
            if len(user)==0:
                #generamos una sal unica
                salt = hashlib.sha256(os.urandom(60)).hexdigest().encode('ascii')
                #genenramos la clave encriptada y con relentizado y sal
                key = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), salt, 65536)
                
                #generamos la semilla para el totp
                seed = base64.b32encode(os.urandom(60)).decode()
                
                #Creación del documento a insertar
                user = {"name" : name, 
                        "country" : country, 
                        "email" : email,
                        "credentials" : {
                                "nickname" : nickname,
                                "password" : key,
                                "salt" : salt,
                                "seed" : seed
                        }}
                
                insertUser = colUser.insert_one(user)
                newUser = colUser.find_one({"_id": insertUser.inserted_id})
                title = "Bienvenido usuario " + newUser["name"]
                
                #le proporcionamos los datos al usuario por si quiere introducirlos manualmente
                content = " Configura Google Authenticator, para ello introduce en la aplicación de forma manual el Nombre de la cuenta: "+ newUser["credentials"]["nickname"]+ " y Tu clave: " + newUser["credentials"]["seed"]
                #Generamos la url que irá en el codigo QR con los datos de el usuario
                qr = "otpauth://totp/Practica%2010%20Usuario%3A%20"+newUser["credentials"]["nickname"]+"?secret="+seed+"&issuer=Practica10&algorithm=SHA256"
                
                return template("Result.tpl", tabTitle = "Bienvenido_totp", title = title, content = content, qr = qr)
            else:
                return template("Result.tpl", tabTitle = "Error_totp", title = "Error en alias", content = "El alias de usuario ya existe", qr = "")
        else:
            return template("Result.tpl", tabTitle = "Error_totp", title = "Error en contraseña", content = "Las contraseñas no coinciden", qr = "")
    else:
        return template("Result.tpl", tabTitle = "Error_totp", title = "Error en campos", content = "Existen algunos campo requeridos incompletos", qr = "")

        
        
@post('/login_totp')        
def login_totp():
    #obtenemos los parametros del formulario
    nickname = request.forms.get('nickname')
    password = request.forms.get('password')
    totp = request.forms.get('totp')
    
    #Verificación de datos introducidos
    if nickname != "" and password != "" and totp != "":
        #Verificación de alias
        #Conexión con el cliente
        client = pymongo.MongoClient()
        #base de datos
        db = client.giw
        #obtencion de la colección
        colUser = db.users
        user = colUser.find_one({'credentials.nickname': nickname})
        if user != None:
            ##verificacion
            salt = user["credentials"]["salt"]
            stored_password = user["credentials"]["password"]
            pwdhash = hashlib.pbkdf2_hmac('sha512', 
                                          password.encode('utf-8'), 
                                          salt, 
                                          65536)

            if pwdhash == stored_password:
                #Verificación en 2 pasos con el totp introducido por el usuario y la semilla de ese usuario almacenada en la bd
                try:
                    secret=user["credentials"]["seed"]
                except:
                    return template("Result.tpl", tabTitle = "Error_totp", title = "Usuario sin registro TOTP", content = "El usuario no tiene activada la verificación en dos pasos, inicie sesión de manera clasica", qr = "")
                
                is_valid = otp.valid_totp(token=totp, secret=secret)
                if is_valid:
                    bienvenida = "Bienvenido " + user["name"]
                    return template("Result.tpl", tabTitle = "Login_totp", title = "Login_totp", content = bienvenida, qr = "")
                else:
                    return template("Result.tpl", tabTitle = "Error_totp", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
            else:
                return template("Result.tpl", tabTitle = "Error_totp", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
        else:
            return template("Result.tpl", tabTitle = "Error_totp", title = "Error usuario o contraseña", content = "Usuario o contraseña incorrectos", qr = "")
    else:
        return template("Result.tpl", tabTitle = "Error_totp", title = "Error en campos", content = "Existen algunos campo requeridos incompletos", qr = "")
    
if __name__ == "__main__":
    # NO MODIFICAR LOS PARÁMETROS DE run()
    run(host='localhost',port=8080,debug=True)
